var secret='abc13nmmAXz'; 
module.exports.key = secret;