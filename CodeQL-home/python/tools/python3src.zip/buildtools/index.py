
from __future__ import print_function, division
import sys
import os
import subprocess
import csv
from contextlib import contextmanager
if (sys.version_info < (3,)):
    from urlparse import urlparse
    from urllib import url2pathname
else:
    from urllib.parse import urlparse
    from urllib.request import url2pathname
from buildtools import discover
from buildtools import install
from buildtools.version import executable

@contextmanager
def suppress_stdout_stderr():
    with open(os.devnull, 'w') as devnull:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = devnull
        sys.stderr = devnull
        try:
            (yield)
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr
INCLUDE_TAG = 'LGTM_INDEX_INCLUDE'
EXCLUDE_TAG = 'LGTM_INDEX_EXCLUDE'
FILTER_TAG = 'LGTM_INDEX_FILTERS'
PATH_TAG = 'LGTM_INDEX_IMPORT_PATH'
REPO_FOLDERS_TAG = 'LGTM_REPOSITORY_FOLDERS_CSV'
REPO_EXCLUDE_KINDS = ('metadata', 'external')

def trap_cache():
    return os.path.join(os.environ['LGTM_WORKSPACE'], 'trap_cache')

def split_into_options(lines, opt):
    opts = []
    for line in lines.split('\n'):
        line = line.strip()
        if line:
            opts.append(opt)
            opts.append(line)
    return opts

def get_include_options():
    if (INCLUDE_TAG in os.environ):
        return split_into_options(os.environ[INCLUDE_TAG], '-R')
    else:
        src = os.environ['LGTM_SRC']
        return ['-R', src]

def get_exclude_options():
    options = []
    if (EXCLUDE_TAG in os.environ):
        options.extend(split_into_options(os.environ[EXCLUDE_TAG], '-Y'))
    if (REPO_FOLDERS_TAG not in os.environ):
        return options
    with open(os.environ[REPO_FOLDERS_TAG]) as csv_file:
        csv_reader = csv.reader(csv_file)
        next(csv_reader)
        for (kind, url) in csv_reader:
            if (kind not in REPO_EXCLUDE_KINDS):
                continue
            try:
                path = url2pathname(urlparse(url).path)
            except:
                print((("Unable to parse '" + url) + "' as file url."))
            else:
                options.append('-Y')
                options.append(path)
    return options

def get_filter_options():
    if (FILTER_TAG in os.environ):
        return split_into_options(os.environ[FILTER_TAG], '--filter')
    else:
        return []

def get_path_options(version):
    path_option = ['-p', install.get_library(version)]
    if (PATH_TAG in os.environ):
        path_option = (split_into_options(os.environ[PATH_TAG], '-p') + path_option)
    return path_option

def get_stdlib():
    return os.path.dirname(os.__file__)

def extractor_options(version):
    base_options = ['-v', '-z', 'all']
    src = os.environ['LGTM_SRC']
    cache_option = ['-c', trap_cache()]
    path_option = get_path_options(version)
    include_options = get_include_options()
    exclude_options = get_exclude_options()
    filter_options = get_filter_options()
    return (((((base_options + cache_option) + path_option) + include_options) + exclude_options) + filter_options)

def main():
    with suppress_stdout_stderr():
        version = discover.get_version()
    tracer = os.path.join(os.environ['SEMMLE_DIST'], 'tools', 'python_tracer.py')
    args = ((executable(version) + ['-S', tracer]) + extractor_options(version))
    print(('Calling ' + ' '.join(args)))
    sys.stdout.flush()
    sys.stderr.flush()
    subprocess.check_call(args)
if (__name__ == '__main__'):
    main()
