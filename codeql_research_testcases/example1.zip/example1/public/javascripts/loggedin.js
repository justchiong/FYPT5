// DOM Ready =============================================================
$(document).ready(function() {

    //Search User button click
    $('#btnLogout').on('click', logout);
});

function logout(){
    window.localStorage.clear();
    window.location.href='/';
}