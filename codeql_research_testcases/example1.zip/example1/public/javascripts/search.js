// Userlist data array for filling in info box
var userListData = [];

// DOM Ready =============================================================
$(document).ready(function() {

    populateTable();

    //Search User button click
    $('#btnReturnHome').on('click', returnHome);
});

// Functions =============================================================

// Fill table with data
function populateTable(){
    var urlParams = new URLSearchParams(window.location.search);

    if (urlParams.has("search")) {
        var search = urlParams.get("search");
    }
    // Empty content string
    var tableContent = '';
    x = '/users/finduser?search=' + search
    // jQuery AJAX call for JSON
    $.getJSON(x, function( data ) {
        // Stick our user data array into a userlist variable in the global object
        userListData = data;

        // For each item in our JSON, add a table row and cells to the content string
        $.each(data, function(){
            tableContent += '<tr>';
            tableContent += '<td>' + this.username + '</td>';
            tableContent += '<td>' + this.fullname + '</td>';
            tableContent += '<td>' + this.email + '</td>';
            tableContent += '<td>' + this.age + '</td>';
            tableContent += '<td>' + this.location + '</td>';
            tableContent += '<td>' + this.gender + '</td>';
            tableContent += '</tr>';
        });

        // Inject the whole content string into our existing HTML table
        $('#userList table tbody').html(tableContent);

  });
}

//Return back
function returnHome(){
    window.location.href='/'
}