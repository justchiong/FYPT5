var express = require('express');
var router = express.Router();
var verifyToken = require('../auth/verifyToken');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Example' });
});

/* GET SEARCH PAGE. */
router.get('/results', function(req,res,next){
  res.render('search', { searchphrase: req.query.search,title:'test'});
});

router.get('/login', function (req, res, next){
  res.render('login', {title:'Example'});
})
module.exports = router;
