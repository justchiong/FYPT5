var express = require('express');
var jwt = require('jsonwebtoken');
var config = require('../auth/config');
var router = express.Router();

/* GET userlist. */
router.get('/userlist', function(req, res) {
  var db = req.db;
  console.log("Getting all users...");
  var collection = db.get('userlist');
  collection.find({},{sort: {username: 1}},function(e,docs){
    res.json(docs);
  });
});

/* GET specific user. */
router.get('/finduser', function(req, res) {
  var db = req.db;
  var search = req.query.search;
  console.log("Finding user...");
  var collection = db.get('userlist');
  collection.find({ 'username' : { '$regex' : search, '$options' : 'i' } },{},function(err ,docs){
    console.log(docs)
    res.json(docs);
  });
});

/* POST to adduser. */
router.post('/adduser', function(req, res) {
  var db = req.db;
  console.log("Adding User...");
  var collection = db.get('userlist');
  collection.insert(req.body, function(err, result){
    res.send(
      (err === null) ? { msg: '' } : { msg: err }
    );
  });
});

/* DELETE to deleteuser. */
router.delete('/deleteuser/:id', function(req, res) {
  var db = req.db;
  console.log("Deleting user...");
  var collection = db.get('userlist');
  var userToDelete = req.params.id;
  collection.remove({ '_id' : userToDelete }, function(err) {
    res.send((err === null) ? { msg: '' } : { msg:'error: ' + err });
  });
});

/* POST to login */
router.post('/login', function(req, res) {
  var db = req.db;
  console.log("User logged in...");
  var collection = db.get('userlist');
  var username = req.body.username;
  var email = req.body.email;
  console.log(username);
  console.log(email);
  collection.findOne({"username":username,"email":email},{},function(err,result){
    if (err) {
      res.sendStatus(500);
    } else {
      console.log(result);
      var token ="";
      if (result != null) {
        token = jwt.sign({ id: result.username }, config.key, {
          expiresIn: 86400 //expires in 24 hrs
        });
        console.log("@@token " + token);
        res.json({success:true, token: token});
      } else {
        res.sendStatus(500);
      }
    }
  })
})
module.exports = router;
