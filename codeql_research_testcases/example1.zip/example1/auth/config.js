var secret='ThIsiSAsEcrETkEy1234!@#$'; 
module.exports.key = secret;