******************CREDTS******************
Part of this webpage was taken from a tutorial from https://closebrace.com/tutorials/2017-03-02/creating-a-simple-restful-web-app-with-nodejs-express-and-mongodb.
It has been modified.

******************INFORMATION******************
This website uses ejs, express and mongodb.
1.open cmd and cd to base folder
2. npm install
3. npm start
4. Access the webpage through localhost:3000