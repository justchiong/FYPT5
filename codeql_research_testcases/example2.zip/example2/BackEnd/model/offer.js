var pool = require('./databaseConfig.js');

var offerDB = {
    addOffer: function (offer, fk_listing_id, fk_offeror_id, status, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = `insert into offers(offer,fk_listing_id,fk_offeror_id,status) values('${offer}', '${fk_listing_id}', '${fk_offeror_id}', '${status}')`;
                client.query(sql, [], function (err, result) {
                    release()
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result);
                    }
                })
            }
        })
    },
    getOffers: function (userid, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = `select u.username,o.offer,l.title,o.id from users u,listings l,offers o where u.id = o.fk_offeror_id and l.id = o.fk_listing_id and o.status = 'pending' and l.fk_poster_id = $1;`;
                client.query(sql, [userid], function (err, result) {
                    release();
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result.rows)
                    }
                })

            }
        })
    },
    AcceptOrRejectOffer: function (status,offerid, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = `update offers set status = $1 where id = ${offerid};`;
                client.query(sql, [status], function (err, result) {
                    release()
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result)
                    }
                })

            }
        })
    },
    getOfferStatus: function (userid, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = `select u.username,o.offer,l.title,o.status from users u,listings l,offers o where o.fk_listing_id = l.id and l.fk_poster_id = u.id and o.fk_offeror_id = $1 and (o.status = 'accepted' or o.status = 'rejected');`;
                client.query(sql, [userid], function (err, result) {
                    release();
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result.rows)
                    }
                })
            }
        })
    },
}

module.exports = offerDB;