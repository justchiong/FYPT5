var config = require('../config.js');
var jwt = require('jsonwebtoken');
const pool = require('./databaseConfig.js');

var userDB = {

	loginUser: function (email, password, callback) {
		pool.connect( function (err, client, release){
			if (err) {
				console.log(err);
				return callback(err,null,null);
			} else {
				var sql = `select * from users where email = '${email}' and password = '${password}'`;
				client.query(sql, [], function (err, result) {
					release();
					if (err) {
						console.log("Err: " + err);
						return callback(err, null, null);
		
					} else {
						var token = "";
						resultrow = result.rows
						if (resultrow.length == 1) {
							token = jwt.sign({ id: resultrow[0].id }, config.key, {
								expiresIn: 86400 //expires in 24 hrs
							});
							console.log("@@token " + token);
							return callback(null, token, resultrow);
						} //if(res)
						else {
							console.log("email/password does not match");
							var err2 = new Error("Email/Password does not match.");
							err2.statusCode = 404;
							console.log(err2);
							return callback(err2, null, null);
						}
					}
				})
			}
		});
	},

	updateUser: function (username, firstname, lastname, id, callback) {
		pool.connect( function (err, client, release) {
			if (err) {
				console.log(err);
				return callback(err, null);
			} else {
				var sql = "update users set username = $1,firstname = $2,lastname = $3 where id = $4;";
				client.query(sql, [username, firstname, lastname, id], function (err, result) {
					release();
					if (err) {
						console.log(err);
						return callback(err, null);
					} else {
						console.log("No. of records updated successfully: " + result.rowCount);
						return callback(null, result.rowCount);
					}
				})
			}
		})
	},

	addUser: function (username, email, password, profile_pic_url, role, callback) {
		pool.connect( function (err, client, release) {
			if (err) {
				console.log(err);
				return callback(err,null);
			} else {
				var sql = "Insert into users(username,email,password,profile_pic_url,role) values($1,$2,$3,$4,$5)";
				client.query(sql, [username, email, password, profile_pic_url, role], function (err, result){
					release();
					if (err) {
						console.log(err);
						return callback(err, null);
					} else {
						return callback(null, result);
					}
				})
			}

		})
	},
};


module.exports = userDB;