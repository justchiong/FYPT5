const pool = require('./databaseConfig.js');

var likesDB = {
    insertLike: function (fk_liker_id,fk_listing_id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = 'insert into likes(fk_liker_id,fk_listing_id) values($1,$2)';
                client.query(sql, [fk_liker_id,fk_listing_id], function (err, result) {
                    release();
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result)
                    }
                })
            }
        })
    },
    deleteLike: function (fk_liker_id,fk_listing_id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = 'delete from likes where fk_liker_id = $1 and fk_listing_id = $2';
                client.query(sql, [fk_liker_id,fk_listing_id], function (err, result) {
                    release()
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result)
                    }
                })
            }
        })
    },
    checklike: function (fk_liker_id,fk_listing_id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = 'select * from likes where fk_liker_id = $1 and fk_listing_id = $2';
                client.query(sql, [fk_liker_id,fk_listing_id], function (err, result) {
                    release();
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result.rows);
                    }
                })
            }
        })
    },
    getLike: function (fk_listing_id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = 'select * from likes where fk_listing_id = $1';
                client.query(sql, [fk_listing_id], function (err, result) {
                    release()
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result)
                    }
                })
            }
        })
    },
}

module.exports = likesDB;