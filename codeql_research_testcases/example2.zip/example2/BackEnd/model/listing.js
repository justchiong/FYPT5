

var pool = require('./databaseConfig.js');

var listingDB = {
    addListing: function (title, category, description, price, fk_poster_id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = 'insert into listings(title,category,description,price,fk_poster_id) values($1,$2,$3,$4,$5) returning id;';
                client.query(sql, [title, category, description, price, fk_poster_id], function (err, result) {
                    release();
                    if (err) {
                        console.log("Err: " + err);
                        return callback(err, null);
                    } else {
                        return callback(null, result.rows[0])
                    }
                })
            }
        })
    },
    getUserListings: function (userid, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                var sql = `select l.title,l.category,l.price,l.id,i.name from listings l,images i where l.id = i.fk_product_id and fk_poster_id = ${userid}`
                client.query(sql, [], function (err, result){
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        return callback(null, result.rows);
                    }
                })
            }
        })
    },
    getListing: function (id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "select l.title,l.category,l.description,l.price,u.username,l.fk_poster_id,i.name from listings l,users u,images i where l.id = $1 and l.id = i.fk_product_id and l.fk_poster_id = u.id";
                client.query(sql, [id], function (err, result) {
                    release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result)
                        return callback(null, result.rows)
                    }
                })
            }
        })
    },
    getOtherUsersListings: function (query, userid, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "select l.title,l.category,l.price,l.id,i.name from listings l,images i where l.id = i.fk_product_id and l.fk_poster_id != $1 and l.title ilike '%" + query + "%'";
                client.query(sql, [userid], function (err, result) {
                    release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        return callback(null, result);
                    }
                });
            }
        })
    },
    updateListing: function (title, category, description, price, id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "update listings set title = $1,category = $2,description = $3,price = $4 where id = $5";
                client.query(sql, [title, category, description, price, id], function (err, result) {
                    release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        return callback(null, result);
                    }
                })
            }
        })
    },
    deleteListing: function (id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "delete from listings where id = $1";
                client.query(sql, [id], function (err, result) {
                    release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        return callback(null, result)
                    }
                });
            }
        })
    },
}

module.exports = listingDB;