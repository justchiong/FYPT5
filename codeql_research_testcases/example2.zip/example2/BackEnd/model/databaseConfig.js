const Pool = require("pg").Pool;

//Start new instance of pool
const pool = new Pool({
    user: "postgres",
    password: "password",
    host: "localhost",
    port: 5432,
    database: "example2"
})

//Export pool
module.exports = pool;