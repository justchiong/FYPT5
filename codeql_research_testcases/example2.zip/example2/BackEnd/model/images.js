var pool = require('./databaseConfig.js');

var imagesDB = {
    uploadImage: function (name,fk_product_id, callback) {
        pool.connect( function (err, client, release) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                var sql = "insert into images(name,fk_product_id) values($1,$2)";
                client.query(sql, [name,fk_product_id], function (err, result) {
                    release()
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        return callback(null, result)
                    }
                });
            }
        })
    },
}

module.exports = imagesDB;