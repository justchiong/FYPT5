var secret='RPU<Yzdf.)KqD}xs6+/?^K`fs9mPWsH[()ta(X#$'; 
module.exports.key = secret;